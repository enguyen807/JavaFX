package Table;

import java.text.SimpleDateFormat;
import java.util.Date;

public class People 
{
    private String lname;
    private String fname;
    private String food;
    private String drinks;
    private String time;
    private String dateString;
    
    public People() 
    {
        this.lname = "";
        this.fname = "";
        this.food = "";
        this.drinks = "";
//        this.time = "";
    }
    
    public People(String fname,String lname, String food, String drinks,String time)
    {
        this.fname=fname;
        this.lname=lname;
        this.food=food;
        this.drinks=drinks;
        this.time=time;
    }
    
    public String getTime()
    {
        SimpleDateFormat date = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm");
        Date currTime1 = new Date();
        String time = date.format(currTime1);
        return time;
    }
    
    public void setTime()
    {
        this.time=time;
    }
    

    /**
     * @return the last name
     */
    public String getLname() {
        return lname;
    }

    /**
     * @param lname the name to set
     */
    public void setLname(String lname) {
        this.lname = lname;
    }

    /**
     * @return the food
     */
    public String getFood() {
        return food;
    }

    /**
     * @param food the food to set
     */
    public void setFood(String food) {
        this.food = food;
    }

    /**
     * @return the drinks
     */
    public String getDrinks() {
        return drinks;
    }

    /**
     * @param drinks the drinks to set
     */
    public void setDrinks(String drinks) {
        this.drinks = drinks;
    }

    /**
     * @return the first name
     */
    public String getFname() {
        return fname;
    }

    /**
     * @param fname the fname to set
     */
    public void setFname(String fname) {
        this.fname = fname;
    }
}
