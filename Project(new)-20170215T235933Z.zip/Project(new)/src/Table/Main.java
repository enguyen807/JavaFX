package Table;
//http://javafxportal.blogspot.com/2012/03/java-how-to-get-current-date-time-date.html



import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Writer;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
//import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
//import javafx.scene.control.ButtonType;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.stage.WindowEvent;


public class Main extends Application
{
    Stage window;
    TableView<People> table;
    TextField lnameInput,fnameInput,foodInput,drinksInput;
    BorderPane layout;
    
    public static void main(String[] args)
    {
        launch(args);
    }
    
    @Override
    public void start(Stage primaryStage) throws Exception
    {
       window = primaryStage;
       window.setTitle("Event TimeSheet (Beta)");
       window.setOnCloseRequest(new EventHandler<WindowEvent>() 
               {
                   @Override
                   public void handle(final WindowEvent e)
                   {
                       e.consume();
                       closeProgram();
                   }
               });
//       window.setOnCloseRequest(e -> 
//       {
//           e.consume();
//           closeProgram();
//       });
       
       // STYLES
       
              
       
//Columns
       //Last Name Column
       TableColumn<People, String> lnameColumn = new TableColumn<>("Last Name");
       lnameColumn.setMinWidth(170);
       lnameColumn.setCellValueFactory(new PropertyValueFactory<People, String>("lname"));
       lnameColumn.setCellFactory(TextFieldTableCell.<People>forTableColumn());
       lnameColumn.setOnEditCommit
        (
                 new EventHandler<CellEditEvent<People, String>>() {
                @Override
                public void handle(CellEditEvent<People, String> t) {
                    ((People) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                        ).setLname(t.getNewValue());
                }
            
        
        }  
//                (CellEditEvent<People, String> t) -> 
//                {
//                ((People) t.getTableView().getItems().get(
//                 t.getTablePosition().getRow())
//                ).setLname(t.getNewValue());
//                }
        );
       
       
       //First Name Column
       TableColumn<People,String> fnameColumn = new TableColumn<>("First Name");
       fnameColumn.setMinWidth(170);
       fnameColumn.setCellValueFactory(new PropertyValueFactory<People,String>("fname"));
       fnameColumn.setCellFactory(TextFieldTableCell.<People>forTableColumn());
       fnameColumn.setOnEditCommit
        (
            
             new EventHandler<CellEditEvent<People, String>>() {
            @Override
            public void handle(CellEditEvent<People, String> t) 
            {
                ((People) t.getTableView().getItems().get(
                    t.getTablePosition().getRow())
                    ).setFname(t.getNewValue());
            }
            
        
            }
                
                
                
                
//                (CellEditEvent<People, String> t) -> 
//                {
//                ((People) t.getTableView().getItems().get(
//                 t.getTablePosition().getRow())
//                ).setFname(t.getNewValue());
//                }
        );
       
       
       //Food Column
       TableColumn<People, String> foodColumn = new TableColumn<>("Food");
       foodColumn.setMinWidth(150);
       foodColumn.setCellValueFactory(new PropertyValueFactory<People, String>("food"));
       foodColumn.setCellFactory(TextFieldTableCell.<People>forTableColumn());
       foodColumn.setOnEditCommit
        (
                new EventHandler<CellEditEvent<People, String>>() {
            @Override
            public void handle(CellEditEvent<People, String> t) 
            {
                ((People) t.getTableView().getItems().get(
                    t.getTablePosition().getRow())
                    ).setFood(t.getNewValue());
            }
            
        
            }
//                (CellEditEvent<People, String> t) -> 
//                {
//                ((People) t.getTableView().getItems().get(
//                 t.getTablePosition().getRow())
//                ).setFood(t.getNewValue());
//                }
        );
       
       //Drink Column
       TableColumn<People, String> drinkColumn = new TableColumn<>("Drinks");
       drinkColumn.setMinWidth(150);
       drinkColumn.setCellValueFactory(new PropertyValueFactory<People, String>("drinks"));
       drinkColumn.setCellFactory(TextFieldTableCell.<People>forTableColumn());
       drinkColumn.setOnEditCommit
        (
                new EventHandler<CellEditEvent<People, String>>() {
            @Override
            public void handle(CellEditEvent<People, String> t) 
            {
                ((People) t.getTableView().getItems().get(
                    t.getTablePosition().getRow())
                    ).setDrinks(t.getNewValue());
            }
            
        
            }
                
//                (CellEditEvent<People, String> t) -> 
//                {
//                ((People) t.getTableView().getItems().get(
//                 t.getTablePosition().getRow())
//                ).setDrinks(t.getNewValue());
//                }
        );
       
       //TimeIn Column
       TableColumn<People,String> timeColumn = new TableColumn<>("TimeIn");
       timeColumn.setMinWidth(150);
       timeColumn.setCellValueFactory(new PropertyValueFactory<People, String>("time"));
       
//TextFields
       //Last Name Input
       lnameInput = new TextField();
       lnameInput.setPromptText("Last Name");
       lnameInput.setMinWidth(150);
       
       //First Name Input
       fnameInput = new TextField();
       fnameInput.setPromptText("First Name");
       fnameInput.setMinWidth(150);
       
       //Food Input
       foodInput = new TextField();
       foodInput.setPromptText("Foods or none");
       foodInput.setMinWidth(150);
       
       //Drink Input
       drinksInput = new TextField();
       drinksInput.setPromptText("Drinks or none");
       drinksInput.setMinWidth(150);     
       
       //Buttons
       Button addButton = new Button("Add");
       addButton.setOnAction(new EventHandler<ActionEvent>()
       {
           @Override
           public void handle(ActionEvent event )
           {
               
               People ppl = new People();
              
               if (isValidInput(event) )
               {
               ppl.setLname(lnameInput.getText());
               ppl.setFname(fnameInput.getText());
               ppl.setFood(foodInput.getText());
               ppl.setDrinks(drinksInput.getText());
               
               lnameInput.clear();
               fnameInput.clear();
               foodInput.clear();
               drinksInput.clear();
                       if(!Pattern.matches("[a-zA-Z]+", ppl.getLname()))
                       {
                                Alert ltrAlert = new Alert(Alert.AlertType.WARNING, "Warning", ButtonType.OK);
                                Window owner = ((Node) event.getTarget()).getScene().getWindow();
                                ltrAlert.setContentText("Letters Only");
                                ltrAlert.initModality(Modality.APPLICATION_MODAL);
                                ltrAlert.initOwner(owner);
                                ltrAlert.showAndWait();
                       }
                       else
                       {
                           table.getItems().add(ppl);
                       }
               
               }
               else
               {
                  //Do nothing
                   
               }

           }
       });
       Button delButton = new Button("Delete");
       delButton.setOnAction(new EventHandler<ActionEvent>()
       {
           @Override
           public void handle(ActionEvent event)
           {
               ObservableList<People> pplSelected, allPeople;
               allPeople = table.getItems();
               pplSelected = table.getSelectionModel().getSelectedItems();
               allPeople.removeAll(pplSelected);
               
               //JDK 8 Shorthand 
               //pplSelected.forEach(allPeople::remove);
           }
       });
       
       //Creates File menu dropdown box
       Menu fileMenu = new Menu("File");
       
       //New File: Creates new file upon user click all current information will be wiped
       MenuItem newFile = new MenuItem("New...");
                   newFile.setOnAction(new EventHandler<ActionEvent>()
                   {
                       @Override
                       public void handle(ActionEvent e)
                       {
                           ObservableList<People>  allPeople;
                           allPeople = table.getItems();
                           allPeople.removeAll(allPeople);
                       }
                   });
                    fileMenu.getItems().add(newFile);
       
       //Open Menu (don't know how to implement yet)
        MenuItem openFile = new MenuItem("Open...");
                    openFile.setOnAction(new EventHandler<ActionEvent>()
                    {
                        @Override
                        public void handle(ActionEvent e)
                        {
                        
                    
                        }

                    });
       
       
       //Export current data in to a excel csv file
       MenuItem saveFile = new MenuItem("Save...");
                    saveFile.setOnAction(new EventHandler<ActionEvent>()
                     {
                         @Override
                         public void handle(ActionEvent e)
                         {  
                       
                             try
                             {
                                FileChooser choose = new FileChooser();
                                choose.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text doc(*.txt)", "*.txt"));
                                Window stage = null;
                                File x = choose.showSaveDialog(stage);
                                if(!x.getName().contains(".")) {
                                x = new File(x.getAbsolutePath() + ".txt");}
                             }
                             catch (Exception ex)
                             {
                                 ex.printStackTrace();
                             }
                         }
                     });
                    fileMenu.getItems().add(saveFile);
                    
       fileMenu.getItems().add(new SeparatorMenuItem()); //Makes line between menuitem
       
       //Settings: User can switch themes.
       //fileMenu.getItems().add(new MenuItem("Settings..."));
          MenuItem settings = new MenuItem("Settings");
                    settings.setOnAction(new EventHandler<ActionEvent>()
                    {
                        @Override
                        public void handle(ActionEvent e)
                        {
                            
                        }
                    });
       
       fileMenu.getItems().add(new SeparatorMenuItem()); //Makes line between menuitem
       
       //Upon exit menu click all information will wiped and prompt will be asked to save if user
       //wishes to save current information
       MenuItem exit = new MenuItem("Exit...");
                    exit.setOnAction(new EventHandler<ActionEvent>()
               {
                   @Override
                   public void handle(ActionEvent e)
                   {
                     
                     Alert exitAlert = new Alert(Alert.AlertType.CONFIRMATION, "Confirm", ButtonType.OK, ButtonType.CANCEL);
                     exitAlert.setContentText("Are you sure you want to exit?");
                     exitAlert.initModality(Modality.APPLICATION_MODAL);
                     exitAlert.showAndWait();

                                if(exitAlert.getResult() == ButtonType.OK) 
                                {
                                    Platform.exit();
                                }
                                else 
                                {
                                    exitAlert.close();
                                }
                   }

               });
               fileMenu.getItems().add(exit);
       
      
        MenuBar menuBar = new MenuBar();
        menuBar.getMenus().addAll(fileMenu);
  

       
       // Layout for textfields
       HBox hbox = new HBox();
       hbox.setPadding(new Insets(10,10,10,10));
       hbox.setSpacing(10);
       hbox.getChildren().addAll(lnameInput,fnameInput,foodInput, drinksInput,addButton,delButton);
       
       //Adding all items to scene for view
       table = new TableView<>();
       table.setEditable(true);
       table.setItems(getPeople());
       table.getColumns().addAll(lnameColumn, fnameColumn,foodColumn, drinkColumn,timeColumn);
      
       //Entire layout of scenary
       VBox vBox = new VBox();
       vBox.getChildren().addAll(menuBar,table,hbox );
       layout = new BorderPane();
       Scene scene = new Scene(vBox );
       File f = new File("TableStyle.css");
       scene.getStylesheets().clear();
       scene.getStylesheets().add("file:///"+ f.getAbsolutePath().replace("\\", "/"));
       window.setScene(scene);
       window.show();
    }
    

    
    // Array List
    public ObservableList<People> getPeople()
    {
//        Main mn = new Main();
        List<People> list = new ArrayList<>();
        ObservableList<People> peoples = FXCollections.observableArrayList(list);
        peoples.add(new People("Peter","Parker","Fried Crikets","Sugar Water",""));
        
        
        return peoples;
    }

        //Save File
        public void saveFile(ObservableList<People> peoples) throws IOException
        {
           try
           {
               FileOutputStream fos = new FileOutputStream("Objectsavefile.ser");
               ObjectOutputStream oos = new ObjectOutputStream(fos);
               oos.writeObject(new ArrayList<People>(peoples));
               oos.close();
           }
           catch(FileNotFoundException e)
           {
               e.printStackTrace();
           }
           catch(IOException e)
           {
               e.printStackTrace();
           }
            
            
            
            
           //Writer writer = null;
//        try {
//        File file = new File("C:\\People.csv.");
//        writer = new BufferedWriter(new FileWriter(file));
//        for (People peoples : getPeople()) {
//
//            String text = peoples.getFname()+","+peoples.getLname()+","+peoples.getDrinks()+","+peoples.getTime()+ "\n";
//                    //getFirstName() + "," + person.getLastName() + "," + person.getEmail() + "\n";
//
//
//            writer.write(text);
//        }
//    } catch (Exception ex)
//    {
//        ex.printStackTrace();
//    }
 
        }
        
        //Open File
        public String loadFile(File file) throws IOException
        {
            StringBuilder stringBuffer = new StringBuilder();
            BufferedReader bufferedReader = null;
            
            try
            {
                bufferedReader = new BufferedReader(new FileReader(file));
                
                String text;
                while((text = bufferedReader.readLine()) != null)
                {
                    stringBuffer.append(text);
                }
            }
            catch (FileNotFoundException ex) 
            {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }    
            catch (IOException ex) 
            {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            } 
            finally 
            {
                    try 
                    {
                        bufferedReader.close();
                    } 
                    catch (IOException ex) 
                    {
                        Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
                    }
            } 
            return stringBuffer.toString();
        }
    
     
//Validation Section Below
        private void closeProgram()
        {
            Alert exitAlert = new Alert(Alert.AlertType.CONFIRMATION, "Confirm", ButtonType.OK, ButtonType.CANCEL);
            exitAlert.setContentText("Are you sure you want to exit?");
            exitAlert.initModality(Modality.APPLICATION_MODAL);
                     exitAlert.showAndWait();
                     
                if(exitAlert.getResult() == ButtonType.OK) 
                {
                    Platform.exit();
                }
                else 
                {
                    exitAlert.close();
                }
        }

        private boolean isValidInput(ActionEvent event)
        {
            Boolean validInput  = true;
            
               if(lnameInput == null || lnameInput.getText().trim().isEmpty())
               {
                   validInput = false;
                   Alert emptyLastName = new Alert(Alert.AlertType.WARNING, "Warning", ButtonType.OK);
                   Window owner = ((Node) event.getTarget()).getScene().getWindow();
                   emptyLastName.setContentText("Last name is empty");
                   emptyLastName.initModality(Modality.APPLICATION_MODAL);
                   emptyLastName.initOwner(owner);
                   emptyLastName.showAndWait();
                   if(emptyLastName.getResult() == ButtonType.OK)
                   {
                       emptyLastName.close();
                       lnameInput.requestFocus();
                   }
               }
               
               if(fnameInput == null || fnameInput.getText().trim().isEmpty())
               {
                   validInput = false;
                   Alert emptyFirstName = new Alert(Alert.AlertType.WARNING, "Warning", ButtonType.OK);
                   Window owner = ((Node) event.getTarget()).getScene().getWindow();
                   emptyFirstName.setContentText("First name is empty");
                   emptyFirstName.initModality(Modality.APPLICATION_MODAL);
                   emptyFirstName.initOwner(owner);
                   emptyFirstName.showAndWait();
                   if(emptyFirstName.getResult() == ButtonType.OK)
                   {
                       emptyFirstName.close();
                       fnameInput.requestFocus();
                   }
               }
                  if(foodInput == null || foodInput.getText().trim().isEmpty())
               {
                   validInput = false;
                   Alert emptyfoodName = new Alert(Alert.AlertType.WARNING, "Warning", ButtonType.OK);
                   Window owner = ((Node) event.getTarget()).getScene().getWindow();
                   emptyfoodName.setContentText("Please list the food you're bringing; Put none if you aren't bringing anything");
                   emptyfoodName.initModality(Modality.APPLICATION_MODAL);
                   emptyfoodName.initOwner(owner);
                   emptyfoodName.showAndWait();
                   if(emptyfoodName.getResult() == ButtonType.OK)
                   {
                       emptyfoodName.close();
                       foodInput.requestFocus();
                   }
               }
                   if(drinksInput == null || drinksInput.getText().trim().isEmpty())
               {
                   validInput = false;
                   Alert emptydrinksName = new Alert(Alert.AlertType.WARNING, "Warning", ButtonType.OK);
                   Window owner = ((Node) event.getTarget()).getScene().getWindow();
                   emptydrinksName.setContentText("Please list the drink you're bringing; Put NONE if you aren't bringing anything");
                   emptydrinksName.initModality(Modality.APPLICATION_MODAL);
                   emptydrinksName.initOwner(owner);
                   emptydrinksName.showAndWait();
                   if(emptydrinksName.getResult() == ButtonType.OK)
                   {
                       emptydrinksName.close();
                       drinksInput.requestFocus();
                   }
               }

            return validInput;
        }
    
    
}
